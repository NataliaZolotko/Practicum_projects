def registration_locators():
    return None
