main_site = 'https://qa-scooter.praktikum-services.ru'

