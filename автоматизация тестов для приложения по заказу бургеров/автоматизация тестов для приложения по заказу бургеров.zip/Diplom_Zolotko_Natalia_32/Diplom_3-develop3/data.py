main_site = 'https://stellarburgers.education-services.ru'

class Auth:
    email = 'zolotkon_32@gmail.com'
    password = '12345йцуке'