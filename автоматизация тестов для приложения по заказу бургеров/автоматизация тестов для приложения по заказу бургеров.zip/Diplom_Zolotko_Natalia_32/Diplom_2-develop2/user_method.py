import requests
import allure
from data import Url, DataCreateUser
import random
import string
        
class CreateUserMethod:
    @staticmethod
    @allure.step("Создать пользователя")
    def create_user(body):
        return requests.post(f'{Url.BASE_URL}{Url.CREATE_USER}', json=body)
        
    @staticmethod
    @allure.step("Удалить пользователя")
    def delete_user(access_token):
        headers = {"Authorization": access_token}
        return requests.delete(f'{Url.BASE_URL}{Url.DELETE_USER}', headers=headers)
    
       
    @staticmethod
    @allure.step("Авторизация пользователя")
    def auth_user(body):
        return requests.post(f'{Url.BASE_URL}{Url.AUTORIZATION}', json=body)
    
   
    @staticmethod
    @allure.step("Сгенерировать данные для создания пользователя")
    def create_user_body(): 
        random_suffix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=8))
        return {
            "email": f"test_user_{random_suffix}@yandex.ru",
            "password": "password123",
            "name": "User"
        } 
    
    @staticmethod
    @allure.step("Получить информацию о пользователе")
    def get_user_info(access_token):
        headers = {"Authorization": access_token}
        return requests.get(f'{Url.BASE_URL}{Url.DELETE_USER}', headers=headers)