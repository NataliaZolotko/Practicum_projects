import pytest
import requests
import random
import string
from faker import Faker
from user_method import CreateUserMethod
from data import Url


def delete_user_by_token(access_token):
    """Удаление пользователя по токену"""
    headers = {"Authorization": access_token}
    return requests.delete(f'{Url.BASE_URL}{Url.DELETE_USER}', headers=headers)


@pytest.fixture
def temporary_user():
    """Создаем временного пользователя и автоматически удаляем после теста"""
    # Генерируем уникальные данные
    unique_suffix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=6))
    random_str = ''.join(random.choices(string.ascii_lowercase, k=6))     
    data = {
        "email": f"test_{unique_suffix}@yandex.ru",
        "password": "password123",
        "name": f"User{random_str}"
    }
    response = requests.post(f'{Url.BASE_URL}{Url.CREATE_USER}', json=data)
    if response.status_code != 200:
        pytest.skip(f"Не удалось создать пользователя: {response.status_code}")
    response_json = response.json()
    token = response_json.get("accessToken")
    data["access_token"] = token
    
    yield data
    
    # Удаляем пользователя после теста
    if token:
        delete_response = delete_user_by_token(token)
        


@pytest.fixture
def authenticated_user(temporary_user):
    """Авторизованный пользователь"""
    # Авторизуем пользователя
    auth_data = {
        "email": temporary_user["email"],
        "password": temporary_user["password"]
    }
    
    response = requests.post(f'{Url.BASE_URL}{Url.AUTORIZATION}', json=auth_data)
    
    if response.status_code == 200:
        response_json = response.json()
        temporary_user["access_token"] = response_json["accessToken"]
        temporary_user["refresh_token"] = response_json["refreshToken"]
    
    return temporary_user