import requests
import pytest
import random
import string
from faker import Faker
from data import DataCreateUser, Url
from user_method import CreateUserMethod
from generators import generator_create_user_body
import allure

fake = Faker()

class TestCreateUser:                
    @allure.title("Создание пользователя")
    def test_create_user_success(self):
        data = CreateUserMethod.create_user_body()
        response = CreateUserMethod.create_user(data)
        assert response.status_code == 200 and f"Статус код: {response.status_code}"
              

    @allure.title("Проверка, что нельзя создать двух одинаковых пользователей")  
    def test_create_duplicate_user_fails(self, temporary_user):
        data = temporary_user
        first_response = CreateUserMethod.create_user(data)
        duplicate_response = CreateUserMethod.create_user(data)
        assert duplicate_response.status_code == 403 
        
             
    @allure.title("Проверка, что если одного из полей нет, запрос возвращает ошибку")
    @pytest.mark.parametrize("missing_field", ["email", "password","name"])
    def test_create_user_without_required_field(self, missing_field):
        data = generator_create_user_body()
        del data[missing_field]
        response = CreateUserMethod.create_user(data)
        assert response.status_code == 403 

   