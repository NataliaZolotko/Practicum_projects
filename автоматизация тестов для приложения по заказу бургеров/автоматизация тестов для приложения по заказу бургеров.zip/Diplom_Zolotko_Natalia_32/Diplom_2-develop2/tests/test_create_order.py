import requests
import pytest
from data import DataCreateOrder, Url, DataCreateUser, DataAuthUser
from order_method import OrderMethods
from user_method import CreateUserMethod
import allure

class TestCreateOrder:
    @allure.title("Проверка создания заказа без авторизации и с ингредиентами")
    @pytest.mark.parametrize("ingredients_option",[
        (["61c0c5a71d1f82001bdaaa6d"]),  
        (["61c0c5a71d1f82001bdaaa6d"], ["61c0c5a71d1f82001bdaaa6f"])  
])
    def test_create_order_with_ingredeints_not_auth(self, ingredients_option):
        order_data = DataCreateOrder.Create_Order_Body
        order_data["ingredients"] = ingredients_option
        response = OrderMethods.create_order(order_data)
        assert response.status_code == 200, f"Ожидался статус 200, получен {response.status_code}"
        response_json = response.json()
        assert response_json["success"] is True, "Поле success должно быть true"
        assert "name" in response_json, "В ответе должно быть поле name"
        assert "order" in response_json, "В ответе должно быть поле order"
        assert "number" in response_json["order"], "В order должно быть поле number"
    
    @allure.title("Проверка создания заказа без авторизации и без ингредиентов")
    def test_create_order_not_ingredeints_not_auth(self):
        order_data = DataCreateOrder.Create_Order_Body
        order_data["ingredients"] = []
        response = OrderMethods.create_order(order_data)
        assert response.status_code == 400, f"Ожидался статус 400, получен {response.status_code}"
        response_json = response.json()
        assert response_json["success"] is False, "Поле success должно быть false"
        assert response_json["message"] == "Ingredient ids must be provided"
    
    @allure.title("Проверка создания заказа без авторизации и с неверным хешем ингредиентов")
    def test_create_order_incorrect_ingredeints_not_auth(self):
        order_data = DataCreateOrder.Create_Order_Body
        order_data["ingredients"] = ["234jgdjhgk89419"]
        response = OrderMethods.create_order(order_data)
        assert response.status_code == 500, f"Ожидался статус 500, получен {response.status_code}"
        
            
    @allure.title("Проверка создания заказа с авторизацией и с ингредиентами ")
    @pytest.mark.parametrize("ingredients_option", [
        (["61c0c5a71d1f82001bdaaa6d"]),
        (["61c0c5a71d1f82001bdaaa6d"], ["61c0c5a71d1f82001bdaaa6f"])
])
    def test_auth_user_create_order_with_engredeints_with_auth(self, ingredients_option):
        user_data = DataCreateUser.Create_User_Body
        response = CreateUserMethod.create_user(user_data)
        auth_data = DataAuthUser.Auth_User_Body
        response_auth = CreateUserMethod.auth_user(auth_data)
        token = response_auth.json().get("accessToken")
        order_data = DataCreateOrder.Create_Order_Body
        order_data["ingredients"] = ingredients_option
        response = OrderMethods.create_order_with_auth(order_data, token)
        assert response.status_code == 200, f"Ожидался статус 200, получен {response.status_code}"
        response_json = response.json()
        assert response_json["success"] is True, "Поле success должно быть true"
        assert "name" in response_json, "В ответе должно быть поле name"
        assert "order" in response_json, "В ответе должно быть поле order"
        assert "number" in response_json["order"], "В order должно быть поле number"
        
    @allure.title("Проверка создания заказа с авторизацией и без ингредиентов")
    def test_create_order_not_ingredeints_with_auth(self):
        user_data = DataCreateUser.Create_User_Body
        response = CreateUserMethod.create_user(user_data)
        auth_data = DataAuthUser.Auth_User_Body
        response_auth = CreateUserMethod.auth_user(auth_data)
        token = response_auth.json().get("accessToken")   
        order_data = DataCreateOrder.Create_Order_Body
        order_data["ingredients"] = []
        response = OrderMethods.create_order(order_data)
        assert response.status_code == 400,f"Ожидался статус 400, получен {response.status_code}"
        response_json = response.json()   
        assert response_json["success"] is False, "Поле success должно быть false"
        assert response_json["message"] == "Ingredient ids must be provided"
    
    @allure.title("Проверка создания заказа с авторизацией и с неверным хешем ингредиентов")
    def test_create_order_incorrect_ingredeints_not_auth(self):
        user_data = DataCreateUser.Create_User_Body
        response = CreateUserMethod.create_user(user_data)
        auth_data = DataAuthUser.Auth_User_Body
        response_auth = CreateUserMethod.auth_user(auth_data)
        token = response_auth.json().get("accessToken")
        order_data = DataCreateOrder.Create_Order_Body
        order_data["ingredients"] = ["234jgdjhgk89419"]
        response = OrderMethods.create_order(order_data)
        assert response.status_code == 500, f"Ожидался статус 500, получен {response.status_code}"
            