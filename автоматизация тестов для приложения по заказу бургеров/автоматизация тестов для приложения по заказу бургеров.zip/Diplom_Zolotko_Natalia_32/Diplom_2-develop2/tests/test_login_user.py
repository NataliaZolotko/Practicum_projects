import requests
import pytest
import random
import string
from faker import Faker
from data import DataCreateUser, Url, DataAuthUser
from user_method import CreateUserMethod
from generators import generator_create_user_body
import allure

fake = Faker()

class TestLoginCourier:
    @allure.title("Успешная авторизация пользователя")
    @allure.description("Вход под существующим пользователем") 
    def test_auth_user(self):
        user_data = DataCreateUser.Create_User_Body
        response = CreateUserMethod.create_user(user_data)
        data = DataAuthUser.Auth_User_Body
        response = CreateUserMethod.auth_user(data)
        assert response.status_code == 200 
    

    @allure.title("Вход с неверным паролем")
    def test_auth_user_with_incorrect_password(self):
        incorrect_password = {
            "email": "zolotko_32@yandex.ru",  
            "password": fake.password()     
        }
        response = CreateUserMethod.auth_user(incorrect_password)
        assert response.status_code == 401 
    
    @allure.title("Вход с неверным логином")    
    def test_auth_user_with_incorrect_login(self):
        incorrect_email = {
            "email": fake.email(),  
            "password": "12345qwer"     
        }
        response = CreateUserMethod.auth_user(incorrect_email)
        assert response.status_code == 401
    
    @allure.title("Вход с неверным логином и паролем")
    def test_auth_user_with_incorrect_login_and_password(self):
        incorrect_all = {
            "email": "",  
            "password": ""     
        }
        response = CreateUserMethod.auth_user(incorrect_all)
        assert response.status_code == 401
