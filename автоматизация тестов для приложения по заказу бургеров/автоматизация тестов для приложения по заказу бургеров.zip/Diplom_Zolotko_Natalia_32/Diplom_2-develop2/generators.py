from faker import Faker
import random

fake = Faker()


def generator_create_user_body():
    return {
        "email": fake.email(),
        "password": fake.password(),
        "name": fake.name()
    }

def generator_auth_user_body():
    return {
        "email": fake.email(),
        "password": fake.password()
    }