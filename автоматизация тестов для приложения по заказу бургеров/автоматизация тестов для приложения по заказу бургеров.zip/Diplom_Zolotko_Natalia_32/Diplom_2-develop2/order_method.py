import requests
from data import Url
import allure

class OrderMethods:
    @staticmethod
    @allure.step("Создать заказ")
    def create_order(body):
        return requests.post(f'{Url.BASE_URL}{Url.CREATE_ORDER}', json=body)
    
    @staticmethod
    @allure.step("Создать заказ с авторизацией")
    def create_order_with_auth(body, token):
        headers = {
        "Authorization": f"{token}",  # Или "Bearer {token}" в зависимости от API
        "Content-Type": "application/json"
    }
        return requests.post(f'{Url.BASE_URL}{Url.CREATE_ORDER}', json=body, headers=headers)
    