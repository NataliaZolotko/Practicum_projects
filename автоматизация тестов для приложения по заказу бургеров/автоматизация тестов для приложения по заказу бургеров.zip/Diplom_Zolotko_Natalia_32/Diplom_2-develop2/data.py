class Url:
    BASE_URL = 'https://stellarburgers.education-services.ru'
    CREATE_USER = '/api/auth/register'
    AUTORIZATION = '/api/auth/login'
    CREATE_ORDER = '/api/orders'
    DELETE_USER = '/api/auth/user'
  
    

class DataCreateOrder:
    Create_Order_Body = {
   "ingredients": ["61c0c5a71d1f82001bdaaa6d","61c0c5a71d1f82001bdaaa6f"]
}

class DataCreateUser:
    Create_User_Body = {
    "email": "zolotko_32@yandex.ru",
    "password": "12345qwer",
    "name": "Наталья"
}

class DataAuthUser:
    Auth_User_Body = {
    "email": "zolotko_32@yandex.ru",
    "password": "12345qwer"
}




