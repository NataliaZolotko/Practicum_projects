from data import DataCreateOrder
from data import DataCreateUser


def modify_create_order(key,value):
    body = DataCreateOrder.Create_Order_Body.copy()
    body[key] = value
    return body

def modify_create_user(key,value):
    body = DataCreateUser.Create_User_Body.copy()
    body[key]=value
    return body